                Core name: Xilinx LogiCORE Floating Point Operator C Model
                Version: 6.0.2
                Release Date: January 18, 2012


================================================================================

This document contains the following sections:

1. Introduction
2. New Features
3. Supported Platforms
4. Resolved Issues
5. Known Issues
6. Technical Support
7. Other Information
8. Core Release History
9. Legal Disclaimer

================================================================================


1. INTRODUCTION

For installation instructions for this release, please go to:

   http://www.xilinx.com/ipcenter/coregen/ip_update_install_instructions.htm

For system requirements:

   http://www.xilinx.com/ipcenter/coregen/ip_update_system_requirements.htm

This file contains release notes for the Xilinx LogiCORE IP Floating Point 
Operator v6.0 C Model revision 1. For the latest updates, see the product 
page at:

   http://www.xilinx.com/products/ipcenter/FLOATING_PT.htm


2. NEW FEATURES

   - None


3. SUPPORTED PLATFORMS

The following platfoms are supported by the core for this release:

   - Windows NT 32-bit and 64-bit - built using Microsoft Visual Studio 2008
   - Linux 32-bit and 64-bit      - built using GNU GCC 4.1.1


4. RESOLVED ISSUES

   - xip_fpo_fixtoflt can round small negative numbers to zero when underflow
     should not occur
     - CR632728


5. KNOWN ISSUES

The following are known issues for v6.0.2 of this C model at time of release:

   - None

The most recent information, including known issues, workarounds, and
resolutions for this version is provided in the IP Release Notes Guide
located at

   www.xilinx.com/support/documentation/user_guides/xtp025.pdf


6. TECHNICAL SUPPORT

To obtain technical support, create a WebCase at www.xilinx.com/support.
Questions are routed to a team with expertise using this product.

Xilinx provides technical support for use of this product when used
according to the guidelines described in the core documentation, and
cannot guarantee timing, functionality, or support of this product for
designs that do not follow specified guidelines.


7. OTHER INFORMATION

   Full documentation of the C model is provided in the User Guide
   "ug812_floating_point_cmodel.pdf".

   Portions of the deliverables provided, specifically the MPIR library,
   the MPFR library, and Visual Studio project files for MPFR, are
   governed by the GNU Lesser General Public License.  See section 9 in
   this README, the source code for these portions, and the accompanying
   Floating Point Operator C model User Guide for details.

   Source code for the MPIR library, the MPFR library, and the Visual
   Studio project files for MPFR, can be obtained from
   www.xilinx.com/guest_resources/gnu/


8. CORE RELEASE HISTORY

Date        By            Version      Description
================================================================================
01/18/2012  Xilinx, Inc.  6.0.2        Resolve issue CR632728
10/19/2011  Xilinx, Inc.  6.0.1        Resolve issue CR623569
06/22/2011  Xilinx, Inc.  6.0          First release of C model
================================================================================


9. LEGAL DISCLAIMER

(c) Copyright 2011-2012 Xilinx, Inc. All rights reserved.

This file contains confidential and proprietary information
of Xilinx, Inc. and is protected under U.S. and 
international copyright and other intellectual property
laws.

DISCLAIMER
This disclaimer is not a license and does not grant any
rights to the materials distributed herewith. Except as
otherwise provided in a valid license issued to you by
Xilinx, and to the maximum extent permitted by applicable
law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
(2) Xilinx shall not be liable (whether in contract or tort,
including negligence, or under any other theory of
liability) for any loss or damage of any kind or nature
related to, arising under or in connection with these
materials, including for any direct, or any indirect,
special, incidental, or consequential loss or damage
(including loss of data, profits, goodwill, or any type of
loss or damage suffered as a result of any action brought
by a third party) even if such damage or loss was
reasonably foreseeable or Xilinx had been advised of the
possibility of the same.

CRITICAL APPLICATIONS
Xilinx products are not designed or intended to be fail-
safe, or for use in any application requiring fail-safe
performance, such as life-support or safety devices or
systems, Class III medical devices, nuclear facilities,
applications related to the deployment of airbags, or any
other applications that could lead to death, personal
injury, or severe property or environmental damage
(individually and collectively, "Critical
Applications"). Customer assumes the sole risk and
liability of any use of Xilinx products in Critical
Applications, subject only to applicable laws and
regulations governing limitations on product liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
PART OF THIS FILE AT ALL TIMES.



Source code for the MPIR library, the MPFR library, and the Visual
Studio project files for MPFR, can be obtained from
www.xilinx.com/guest_resources/gnu/



The MPIR Library is governed by the following disclaimer:

Copyright 1991, 1996, 1999, 2000 Free Software Foundation, Inc.

Copyright 2008, 2009 William Hart

The MPIR Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The MPIR Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the MPIR Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
02110-1301, USA.



The MPFR Library is governed by the following disclaimer:

Copyright 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011 Free Software Foundation, Inc.
Contributed by the Arenaire and Cacao projects, INRIA.

The GNU MPFR Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3 of the License, or (at your
option) any later version.

The GNU MPFR Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MPFR Library; see the file COPYING.LESSER.  If not, see
http://www.gnu.org/licenses/ or write to the Free Software Foundation, Inc.,
51 Franklin St, Fifth Floor, Boston, MA 02110-1301, USA.



The Visual Studio project files for MPFR are governed by the following disclaimer:

Where files in this distribution have been derived from files licensed
under Gnu GPL or LGPL license terms, their headers have been preserved 
in order to ensure that these terms will continue to be honoured.  

Other files in this distribution that have been created by me[1] for use
in building MPIR and MPFR using Microsoft Visual Studio 2008 are 
provided under the terms of the LGPL version 2.1

[1]: Brian Gladman; see http://gladman.plushost.co.uk/oldsite/computing/gmp4win.php
